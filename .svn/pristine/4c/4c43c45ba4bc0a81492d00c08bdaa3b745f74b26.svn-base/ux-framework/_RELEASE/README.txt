*****************************
UX Framework Release Notes
*****************************

As of 7/18/19, I am changing the way we version releases. Instead of versioning "USPS-bootstrap" and "USPS-glyphs" seperately, I am bundeling up the entire frame work (file name: ux-framework.zip) and versoning that. This will make it easier to keep track of updates and sync the glyphis and bootstrap versions. All previous verions of glyphs and bootstrap saved using the old method are still available in the "ux-framework.zip" file. Please contact mw with any concerns or questions.

-Jason Lewis