*******************************************************************
** USPS Bootstrap Library:
** Last Edited: 12/26/2018, BNSDD0
*******************************************************************

# Introduction
This is the bootstrap library with USPS branding along with demos.

# Versioning
Version this library by the following:

v1.0.3 || V.R.P   Version.Release.Patch

Increase the Patch number whenever there are some edits or fixes needed.
Increase the Release/Branch number whenever there are new components or styling.
DO NOT increase the version number unless there are breaking changes.

# Using Subversion
If a patch is needed, make changes to the current branch. 
Once you are done, create a new tag with a new patch number (i.e. v1.0.2 to v1.0.3).
ZIP up the usps-bootstrap directory (without the demo) and include this in the tag.
Include the version on the file (i.e. usps-bootstrap-1.0.3.zip)
 
If a release is needed, make a new branch and switch to it. 
Once you are done, create a new tag with a new release/patch number (i.e. v1.0.3 to v1.1.0).
ZIP up the usps-bootstrap directory (without the demo) and include this in the tag.
Include the version on the file (i.e. usps-bootstrap-1.1.0.zip)

# Releasing to Developers
Indicate to the developer where they can grab the ZIP file and begin working.
Indicate to the developer where the demo is located at to view it.