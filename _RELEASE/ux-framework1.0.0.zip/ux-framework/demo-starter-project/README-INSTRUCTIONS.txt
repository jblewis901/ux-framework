=== TEMPLATE INSTRUCTIONS ===

1. Create a HTML project folder
2. Create an asset folder
3. Create a lib folder inside asset 

4. Copy one of the blank slate html to your HTML project folder 
5. Copy the favicon.png from the template asset folder to your project asset folder .
6. Grab the latest _RELEASE ZIP of USPS Bootstrap and USPS Glyphs from the UX framework folder, and paste it inside the asset lib folder.
7. Unzip the ZIP files to the asset lib folder

8. Try your app.